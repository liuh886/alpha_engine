# AlphaEngine 10D Model Decision Pack

Decision status: **rejected**
Trade ready: **False**

## Current best candidate

- Candidate: `none`
- Mean ICIR: `n/a`
- Mean Rank IC: `n/a`
- Mean spread: `n/a`
- Worst drawdown: `n/a`
- Ready ratio: `n/a`

## Failed trade-guidance gates

- `stable_research_candidate`

## Warning

Promotion status is research evidence, not authorization for live or automated trading.

## Recommended next step

Resolve failed evidence or stability gates before further promotion.
