# AlphaEngine 10D Model Decision Pack

Decision status: **research_candidate**
Trade ready: **False**

## Current best candidate

- Candidate: `xgb:daily_ranker:cn_balanced_ohlcv:gain5_round100_leaves31_leaf10_lr0.05/xgb_rank_ndcg/original`
- Mean ICIR: `0.2593826`
- Mean Rank IC: `0.0282758`
- Mean spread: `0.01669149`
- Worst drawdown: `-0.16116`
- Ready ratio: `0.2`

## Failed trade-guidance gates

- `mean_icir`
- `worst_drawdown`
- `ready_ratio`

## Warning

Promotion status is research evidence, not authorization for live or automated trading.

## Recommended next step

Keep the candidate research-only and improve evidence quality. Failed gates: mean_icir, worst_drawdown, ready_ratio.
